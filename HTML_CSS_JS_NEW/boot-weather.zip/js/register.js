;(function () {
   const email = document.querySelector
})()
