const userid = document.querySelector('#userid')
const pwd1 = document.querySelector('#pwd1')
const pwd2 = document.querySelector('#pwd2')
const level = document.querySelector('#level')
const fullname = document.querySelector('#fullname')
const email = document.querySelector('#email')
const tel = document.querySelector('#tel')
const submitButton = document.querySelector('#submit_button')

//전송 버튼 클릭시
submitButton.addEventListener('click', () => {
   idConfirm()
})

function idConfirm() {
   const mustId = document.querySelector('.must_id')
   const overlap = document.querySelector('.overlap')

   //텍스트가 남아있는 걸 방지하기 위한 초기화
   mustId.style.display = 'none'
   overlap.style.display = 'none'

   //공백입력 여부
   if (!userid.value) {
      //공백일때
      mustId.style.display = 'block'
      return false
   } else {
      //공백이 아닐때
      //아이디 중복여부 체크 -> 서버 프로그래밍 구현 필요
      if (!idCheck(userid.value)) {
         //아이디가 중복이면
         overlap.style.display = 'block'
         return false
      }
   }

   return true
}

function pwd1Confirm() {}
function pwd2Confirm() {}
function fullnameConfirm() {}
function emailConfirm() {}
function telConfirm() {}

//중복된 아이디 체크
function idCheck(id) {
   return true //true: 아이디 중복 되지 않음
}

//정규식
function pwdCheck() {}
function telCheck() {}
function emailCheck() {}
